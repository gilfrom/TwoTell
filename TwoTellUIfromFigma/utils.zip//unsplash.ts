export async function unsplashImage(query: string): Promise<string> {
  // This would normally call the unsplash API
  // For now, return a placeholder based on the query
  const encodedQuery = encodeURIComponent(query);
  return `https://source.unsplash.com/800x600/?${encodedQuery}`;
}
